Protokolle der AG Sitzung
