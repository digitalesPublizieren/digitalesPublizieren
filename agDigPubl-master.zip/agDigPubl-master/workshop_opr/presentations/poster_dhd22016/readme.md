Poster der AG präsentiert auf der DHd2016
Auch zu finden unter:
DHd AG Digitales Publizieren (2017). DHd_Leipzig_2016_award_X__3__mini.jpg. DARIAH-DE. https://doi.org/10.20375/0000-000b-ca56-1
