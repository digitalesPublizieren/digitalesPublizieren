Ordner für die Konzeption des Workshop zu Open Peer Review am 25. September 2020.
